# Review: CSG app integration (code review only)

- Seat / run: Grok / `20260908-csg-app-review`. Other seats’ conclusions not read.
- Seat-config 2026-09-08: Grok `grok-4.6` / `xhigh`. Session `summary.json`: `current_model_id=grok-4.6`, `reasoning_effort=xhigh`. Launch: same model/effort, `subagents=false`. Stronger-model check: not re-queried at close-out; config unchanged from this session.
- Input: frozen `inputs/source` + SHA in `inputs/manifest.json`. Allowed unread product deps only. No `docs/ideas`, no `tmp/data`.
- Method: **code review only. No dynamic repro, no tests, no native/WASM confirm, no browser, no AT-040 oracle.** Not a release pass. Source remains a candidate.

## Proven issues (static)

**1. High — default Apply cannot run catalog default `impOp`.**  
`createMeshApplicationServices.prepare` (`inputs/source/src/integration/mesh-services.mjs` ~40) requires `impOp ∈ {han, tru}` or throws `MESH_OPERATION_UNSUPPORTED`. Domain catalog `impOp.macDinh` is `"them"` (`src/domain/catalog.mjs` ~2012–2028; same in `docs/specs/parameters-reference.json`).  
Trigger: `impOn=true`, leave “Cách ghép” at default, import STL/OBJ, `mesh.apply`.  
Impact: default apply never starts CSG; GEO-04 `import-as-part` is on the catalog enum but not on the apply path.  
Fix: implement `them` as a separate part commit, or change default to `han`/`tru` and mark `them` unsupported in UI/schema.

**2. High — micrometre unit key does not exist in the importer table.**  
UI `ParametersSection.tsx` ~198 `value="micrometer"`. App allow-list: `mesh-services.mjs` ~11 and `app-csg-transaction.mjs` `selection()` ~23 (`micrometer`). Importer table `src/mesh-import/src/stl.mjs` ~3 is `micron`, not `micrometer`. `importer.mjs` `importBytes` ~43–49: `Object.hasOwn(UNITS, input.unit)` else `STL_UNIT_REQUIRED` / `OBJ_UNIT_REQUIRED`. Prepare copies `options.unit` into parser/approval (~59–61).  
Trigger: choose micrometres, confirm apply.  
Impact: declared µm never stages; GEO-04 unit declaration fails for that choice. Other units are not claimed broken.  
Fix: one canonical key and a map UI → importer.

**3. High — after CSG, visible block ids cannot be the next target.**  
UI target list is `snapshot.project.blocks` (`ParametersSection.tsx` ~201–206). CSG `wrap()` (`root-app-adapter.mjs` ~108) sets `id = 'mesh:' + proposalHash + ':' + part`. Prepare resolves targets on the **generated-base** `exportDescriptor.parts` by `p.id`, or `@main-body` (`mesh-services.mjs` ~50). Those id schemes are different.  
Trigger: apply CSG, pick a listed part, apply again.  
Impact: `MESH_TARGET_ORPHAN`; only `@main-body` remains usable. Reapply/retarget from the shown scene is false.  
Fix: map visible block → generated-base/semantic id, or do not offer synthetic CSG ids.

**4. High — undo/redo persist does not restore CSG model or generation.**  
GEO-04: apply/cancel/undo atomic; last valid snapshot and correct generation. `adoptMesh` (`mesh-transactions.mjs` ~10–23) installs the CSG lease, `workspaceStep=2`. `ProjectOperations.persist` (`projects.mjs` ~19–35) writes CAS head, drops proposal/preview/job, **does not** `clearVisible` or rebuild. `open()` does `clearVisible` (~53–61); undo does not. `JobOperations.build` (`jobs.mjs` ~21–22) only replays if `mesh.applied`.  
Trigger: undo the `mesh.apply` transaction (or any persist while that lease is visible).  
Impact: document reverts; viewport still shows CSG; `ticket.revision !== state.revision` (`controller.mjs` `makeSnapshot` matching / `visibleModelStale`). Displayed generation is the undone result. Export may gate on matching-model; the view still lies.  
Fix: on mesh-affecting undo/redo, `clearVisible` or restore the previous lease; require rebuild at the restored revision.

## Missing GEO-04 (unsupported, not silent geometry)

- `import-as-part` / `them`: rejected, not implemented.
- “Hàn khối chạm nhiều nhất” (largest positive intersection volume, else contact area, stable id): no such selector; explicit `@main-body` or part id only.
- AT-040.1–5 (analytic volumes, open/non-manifold reject, tie-break, five products, SVG section of **final** scene): not executed. `applied` / toasts are not geometry evidence.

## Untested concerns (not filed as defects)

- `wrap()` does not assert ARCH header generation vs lease generation. Viewport `setModel` (`three-viewport.mjs` ~56–57) checks after `store.commit` (`app-csg-transaction.mjs` `commitCandidate`, `durable=true` then `adopt`). A native/job mismatch would ack then `COMMITTED_MODEL_UNAVAILABLE`. Native confirm stamp was not run.
- `finishMeshResult` reopens only if `editingAllowed()`; durable head vs in-memory doc if locked: unread in a live store.
- OBJ materials all assigned one `importMaterial` (`mesh-services.mjs` ~59–61) with explicit copy; GEO-04 allows an explicit collapse, not keep-all.
- `meshJoinTolerance.mode==='unselected'` required (~41) while `queryToleranceCeilingMm: .002` is sent (~62). Meaning of that native field was not verified; not called a hidden boolean epsilon.
- Two-step handoff, CAS ack-recovery, cancel, replay, `mesh-scene` vs product final-scene routing: consistent on the page, **not executed** (`proposal-handoff.test.mjs` unread as a run).
- Viewport copies GPU arrays (`gpuPart`); use-after-free of native buffers after failed adopt is **not** shown.

## Limits

No STL/OBJ execution, no Worker/CAS, no undo in a store, no SVG export after CSG, no five-product rebuild/orphan, no paid providers, no print/fit claims. ABI buffer grow after CSG confirm: unread.

**Verdict: cần sửa (code review). Not pass. Not geometrically complete.**