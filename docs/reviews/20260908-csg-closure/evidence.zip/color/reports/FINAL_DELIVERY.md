# Production-pair color product retest — PASS

Receipt SHA-256: 439eba1c35c402461d40de8f8ccacb0887ead44bbbc3d402c7b2dd08cc3e1a0d

Exact unchanged case: original Noto COLRv1 U+1F600 -> explicit artwork/render/
palette/source/native product consents -> keychain/noi -> real root product in
Chromium Worker. All 344 captured source/test/dependency files still match the
frozen color delivery. No new code/CAS delta; previous delivery remains unchanged.

Parent production pair was copied and verified by exact bytes/SHA:
- MJS 146452 bytes: c843f337f4ad6a67f5de7fc7a861fb51650437dd3c13c64604cdccf92b4075a4
- WASM 6262007 bytes: 62284897a08fc6669ec18b3e7dc2d17f0d6b74b157fa1e9434b5fc38e311a684

One actual root instance consumed those WASM bytes; one fetch. The observed
export surface has no arch_test_fixture and includes Printing ABI functions.
Printing=true/TestFixtures=false and operation masks15 were parent-qualified;
this case validates the product path, not a printing/CSG operation.

Browser test PASS, exit0, 32.32s total test (33.07s Node runner).
13 mesh parts pass the existing independent indexed numeric topology oracle;
native colors are distinct and mechanics3/source2 remain strict.
The original full COLRv1 font and selection bytes remain exact. Paint graph
before conversion, during conversion and reconstructed from committed source
matches exactly: 60 operations, one gradient, SHA
29c2c9057a1063e56b29f4285d73c1d2d73aba6c2b50f280e704511e92ceca41.

Evidence: evidence/browser-production.txt and
evidence/controller-browser-color-production/chromium/color/summary.json,
color-emoji-converted.oracle.json and the captured original/derived assets.
receipt.json hashes every evidence file plus the checked input manifest.

Only this one source/product case is qualified on the new pair. CSG flows,
printing/export and whole-release checks remain parent-owned. No MAIN/parent/
frozen-room edits, no Opus/subagents. Implementation/self-test only; inherited
Astra/max requested, fast/service-tier unverified, no configured review claim.
